///
/// Copyright 2011-2020 Solace Corporation. All rights reserved.
///
/// This file contains a sample Solace PubSub+ Cache plugin implementation that
/// uses the user-data in the cache message to carry the solCache_opcode_t from
/// the publisher. The plugin must extract the opcode and return it to the cache
/// for processing.

#include "solCachePlugin.h"
#include "solCachePluginDeprecated.h"
#include "solClientMsg.h"


/**
 * This function is called by Solace PubSub+ Cache to to retrieve a null
 * terminated description string for the plugin library. The plugin library must
 * implement this function. The function should return a pointer to a null
 * terminated string with the name and version of the plugin. For example, 
 * "Customer X Plugin vX.X". Note that Solace PubSub+ Cache assumes that the
 * pointer is valid upon return from this function. Also note that Solace
 * PubSub+ Cache does not assume that the pointer points to memory allocated
 * from the heap and will not try to free the memory back to the heap. Use a
 * static buffer or a static pointer to memory allocated once from the heap if
 * the description is created at run time.
 */

extern "C" const char*
solCache_getPluginDescription()
{
    return "Solace Sample Plugin v1.0";
}


/**
 * This function is called by the Solace PubSub+ Cache to handle a cache event.
 * The sample implementation will handle the SOLCACHE_INGRESS_EVENT_DATA_MSG
 * event and do nothing for all other events. For the
 * SOLCACHE_INGRESS_EVENT_DATA_MSG event the function will look for a
 * solCache_opcode_t in the user-data within the cache message. If found the
 * opcode is inserted into the solCache_pluginEventInfo_t. If not found the
 * function will do nothing and the cache will process the default opcode. The
 * publisher of the message can insert an solCache_opcode_t into the message
 * user-data (as a char) using the function solClient_msg_setUserData.
 */

extern "C" void
solCache_plugin(solCache_pluginEventInfo_t *eventInfo_p)
{
    if ( eventInfo_p->event == SOLCACHE_INGRESS_EVENT_DATA_MSG )
    {
        void* bufPtr;
        solClient_uint32_t size;

        solClient_returnCode_t rc = solClient_msg_getUserDataPtr(
            eventInfo_p->msg_p, &bufPtr, &size );

        if ( (rc == SOLCLIENT_OK) && (size == sizeof(char)) )
        {
            eventInfo_p->opcode = (solCache_opcode_t) * (const char*) bufPtr;
        }
    }
}

