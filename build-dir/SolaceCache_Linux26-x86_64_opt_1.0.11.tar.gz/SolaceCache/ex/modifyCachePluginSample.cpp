///
/// Copyright 2011-2020 Solace Corporation. All rights reserved.
///
/// This file contains a sample Solace PubSub+ Cache plugin implementation that
/// uses a Structured Data Type (SDT) in the cache message to carry the 
/// solCache_opcode_t and other operational directives from the publisher. 
/// The plugin is designed to demonstrate all the message modification
/// capabilities available to designers of plugin software.

#define PROVIDE_LOG_UTILITIES

#include "solCachePlugin.h"
#include "solCachePluginDeprecated.h"
#include "solClientMsg.h"

#include <string.h>


/**
 * solCache_getPluginDescription is called by Solace PubSub+ Cache to to retrieve a 
 * null-terminated description string for the plugin library. The plugin library must
 * implement this function. The function should return a pointer to a null terminated 
 * string with the name and version of the plugin. For example, 
 * "Customer X Plugin vX.X". Note that Solace PubSub+ Cache assumes that the pointer is 
 * valid upon return from this function. Also note that Solace PubSub+ Cache does not 
 * assume that the pointer points to memory allocated from the heap and will
 * not try to free the memory back to the heap. Use a static buffer or a static
 * pointer to memory allocated once from the heap if the description is created
 * at run time.
 */

extern "C" const char* 
solCache_getPluginDescription()
{
    return "Solace Modify Cache Sample Plugin v1.1";
}

/**
 * 
 * Maintain two static counters. These counters are incremented on each 
 * invocation of solCache_plugin() and solCache_data_plugin() respectively. 
 * Depending on the contents of received messages, these counts may be added
 * to the structured data in the received message before it is cached.
 */
static int solCachePluginCount_s = 0;
static int solCacheDataPluginCount_s = 0;

/*
 * Function pointer to method to retrieve messages from the cache
 */
solCache_getNextCachedMsgFunc_t sc_getNextCachedMsg_p = NULL;

/**
 * aolcache_data_plugin() is called by Solace PubSub+ Cache to handle SOLCACHE_INGRESS_EVENT_DATA_MSG.
 * This is not the default behaviour.  By default solCache calls solCache_plugin() to handle all events. 
 * However in this sample plugin, SOLCACHE_INGRESS_EVENT_DATA_MSG events are redirected to this function
 * by the handling of the SOLCACHE_INGRESS_EVENT_INIT event. See the implementation of solCache_plugin()
 * that follows solcache_data_plugin().
 * 
 */

/**
 * For the SOLCACHE_INGRESS_EVENT_DATA_MSG event the function:
 *      - Look in the binary attachment for a SDT map. If not found return immediately.
 *      - Look in the SDT map (rxMap)  for uint32 field 'opcode', if present set the solCache_pluginEventInfo_t opcode to the found value.
 *        Otherwise leave the solCache_pluginEventInfo_t at the default value (SOLCACHE_INGRESS_OP_CACHE).
 *      - Look in the SDT map (rxMap)  for the boolean field 'addSubMap', when found and 'true' add a submap, with key 'subMap'.  The submap contains one
 *        element, a string with key 'string-name' and value 'string-value'. Return and let cache continue according to 'opcode'.
 *      - Look in the SDT map (rxMap)  for the string field 'modifyTopic'. If found and it is an empty string, retrieve the oldest cached message on the
 *        same topic as the ingress event data message.  Otherwise, if it is not an empty string, retrieve the oldest cached message on the 
 *        topic indicated in 'modifyTopic'. Replace the incoming message pointer with the retrieved message pointer. Further processing is done
 *        on the retrieved message pointer. If the retrieved message pointer is NULL, set the opcode to 'SOLCACHE_INGRESS_OP_DISCARD' and return. 
 *
 *              - retrieve the binary attachment map (cachedMap) from the message. If it does not exist, create a new map in the binary
 *                attachment replacing any existing contents.
 *              - if the string field 'incCounter' exists in rxMap  use the string value as a key to get a uint32 counter from cachedMap, 
 *                increment and set it in the map (cachedMap). If it does not exist set it to one.
 *              - if the boolean field 'addPluginCount' exists in rxMap, add a uint32 field, 'pluginCount' to cachedMap that contains
 *                 the number of time solCache_plugin() has been invoked. 
 *              - if the boolean field 'addPluginDataCount' exists in rxMap, add a uint32 field, 'pluginDataCount' to cachedMap that
 *                contains the number of time solCache_data_plugin() has been invoked.               
 *
 * See 'Test Scenarios' at the end of this file for a description of some of the abilities that may be tested and demonstrated with this plugin.
 */
 
extern "C" void 
solCache_data_plugin(solCache_pluginEventInfo_t *eventInfo_p)
{
    solClient_opaqueContainer_pt rxMap_p;
    solClient_uint32_t opcode;
    solClient_bool_t boolVal;
    char             cachedTopic[SOLCLIENT_BUFINFO_MAX_TOPIC_SIZE + 1];
    char             fieldName[256];
    
    solCacheDataPluginCount_s ++ ;      // increment counter of number of data events seen 

    solClient_returnCode_t rc = solClient_msg_getBinaryAttachmentMap(
        eventInfo_p->msg_p, &rxMap_p );
        
    if ( rc != SOLCLIENT_OK ) return;
    
    rc = solClient_container_getUint32(rxMap_p, &opcode, "opcode");
    
    if ( rc == SOLCLIENT_OK )
    {
        eventInfo_p->opcode = (solCache_opcode_t) opcode;
    }
    
    rc = solClient_container_getBoolean(rxMap_p, &boolVal, "addSubMap");
    
    if ( rc == SOLCLIENT_OK && boolVal )
    {
        solClient_opaqueContainer_pt subMap_p;
        rc = solClient_container_openSubMap(rxMap_p, &subMap_p, "subMap");
        
        if ( rc == SOLCLIENT_OK )
        {
            solClient_container_addString(subMap_p, "string-value", "string-name");
            solClient_container_closeMapStream(&subMap_p);
        }
        solClient_container_closeMapStream(&rxMap_p);
        return;
    }

    /*
     * We have not added a sub-map to the message, look for commands to modify existing 
     * cache contents. We need to have initialized sc_getNextCachedMsg_p for this code to 
     * be operational.
     */
    if ((sc_getNextCachedMsg_p != NULL) && 
        (rc = solClient_container_getString(rxMap_p, cachedTopic, sizeof(cachedTopic), "modifyTopic")) == SOLCLIENT_OK) 
    {
        solClient_destination_t rxDestination;
        solClient_opaqueMsg_pt  cachedMsg_p;
        solClient_opaqueContainer_pt cachedMap_p;
        solClient_opaqueContainer_pt newFieldsMap_p;
        /*
         * if cachedTopic is the empty string, then retrieve the topic from the incoming message and use it to search for
         * existing cached messages.
         */
        if (cachedTopic[0] == '\0')
        {
            if (solClient_msg_getDestination(eventInfo_p->msg_p, &rxDestination, sizeof(rxDestination)) != SOLCLIENT_OK)
            {
                /*
                 * all messages should contain a topic.
                 */
                solClient_log (SOLCLIENT_LOG_ERROR, "No destination found in received message");
                eventInfo_p->opcode = SOLCACHE_INGRESS_OP_FAIL;
                return;
            }
            else
            {
                strncpy(cachedTopic, rxDestination.dest, sizeof(cachedTopic));
            }
        }
        if ((cachedMsg_p = sc_getNextCachedMsg_p (cachedTopic)) == NULL) 
        {
            eventInfo_p->opcode = SOLCACHE_INGRESS_OP_DISCARD;
            return;
        }
        /*
         * we are going to update the cached message and then Solace PubSub+ Cache will put it back
         * in the cache as the newest message. Replace the received message with the cached message
         */
        eventInfo_p->msg_p = cachedMsg_p;

        /*
         * see if the cached message already contains a map 
         */
        rc = solClient_msg_getBinaryAttachmentMap( cachedMsg_p, &cachedMap_p );
        if (rc != SOLCLIENT_OK) 
        {
            rc = solClient_msg_createBinaryAttachmentMap( cachedMsg_p, &cachedMap_p, 0 );
            if (rc != SOLCLIENT_OK)
            {
                solClient_log (SOLCLIENT_LOG_ERROR, "Unable to create a map in cached message");
                eventInfo_p->opcode = SOLCACHE_INGRESS_OP_FAIL;
                return;
            }
        }
        /*
         * if the received message contains the field 'incCounter', it contains the name of a 
         * counter that is to be incremented in the cached message.
         */
        if (solClient_container_getString(rxMap_p, fieldName, sizeof(fieldName), "incCounter") == SOLCLIENT_OK)
        {
            solClient_uint32_t  counter = 0;

            /*
             * we don't care if fieldName exists or not, if the retrieve and delete fail, counnter will be zero still
             */
            solClient_container_getUint32(cachedMap_p, &counter, fieldName);
            solClient_container_deleteField(cachedMap_p, fieldName);
            counter++;
            if (solClient_container_addUint32(cachedMap_p, counter, fieldName) != SOLCLIENT_OK) 
            {
                solClient_log (SOLCLIENT_LOG_ERROR, "Failed to increment counter '%s' in cached message", fieldName);
            }
        }
        /*
         * if the received message contains the field 'addPluginCount' it is a boolean that when true indicates
         * the plugin should add the solCachePluginCount_s counter to the cached message (number of non-data invocations 
         * of the plugin).
         */
        rc = solClient_container_getBoolean(rxMap_p, &boolVal, "addPluginCount");
        if ( rc == SOLCLIENT_OK && boolVal )
        {
            if (solClient_container_addUint32(cachedMap_p, solCachePluginCount_s , "pluginCount") != SOLCLIENT_OK)
            {
                solClient_log (SOLCLIENT_LOG_ERROR, "Failed to add pluginCount '%d' in cached message", solCachePluginCount_s);
            }
        }
        /*
         * if the received message contains the field 'addPluginDataCount' it is a boolean that when true indicates
         * the plugin should add the solCachePluginDataCount_s counter to the cached message (number of data invocations 
         * of the plugin).
         */
        rc = solClient_container_getBoolean(rxMap_p, &boolVal, "addPluginDataCount");
        if ( rc == SOLCLIENT_OK && boolVal )
        {
            if (solClient_container_addUint32(cachedMap_p, solCacheDataPluginCount_s , "pluginDataCount") != SOLCLIENT_OK)
            {
                solClient_log (SOLCLIENT_LOG_ERROR, "Failed to add pluginCount '%d' in cached message", solCacheDataPluginCount_s);
            }
        }
        /*
         * if the received message contains the field 'deleteField' it contains the name of a field to delete from
         * the cached message
         */
        if (solClient_container_getString(rxMap_p, fieldName, sizeof(fieldName), "deleteField") == SOLCLIENT_OK)
        {
            /*
             * we don't care if fieldName exists or not, try to delete it. If it doesn't exist it won't exist after
             * delete either.
             */
            solClient_container_deleteField(cachedMap_p, fieldName);
        }
        /*
         * if the reeived message contains the map, 'newFieldsMap', iterate over the 'newFieldsMap' and add every field to
         * cachedMap
         */
        if (solClient_container_getSubMap(rxMap_p, &newFieldsMap_p, "newFieldsMap") == SOLCLIENT_OK)
        {
            solClient_field_t   mapEntry;
            const char         *fieldName_p;
            while (solClient_container_getNextField(newFieldsMap_p, &mapEntry, sizeof(mapEntry), &fieldName_p) == SOLCLIENT_OK)
            {
                 solClient_container_deleteField(cachedMap_p, fieldName_p);
                 switch (mapEntry.type)
                 {
                 case SOLCLIENT_BOOL:
                    solClient_container_addBoolean (cachedMap_p, mapEntry.value.boolean, fieldName_p);
                    break;
                 case SOLCLIENT_UINT8:
                    solClient_container_addUint8 (cachedMap_p, mapEntry.value.uint8, fieldName_p);
                    break;
                 case SOLCLIENT_INT8:
                    solClient_container_addInt8 (cachedMap_p, mapEntry.value.int8, fieldName_p);
                    break;
                 case SOLCLIENT_UINT16:
                    solClient_container_addUint16 (cachedMap_p, mapEntry.value.uint16, fieldName_p);
                    break;
                 case SOLCLIENT_INT16:
                    solClient_container_addInt16 (cachedMap_p, mapEntry.value.int16, fieldName_p);
                    break;
                 case SOLCLIENT_UINT32:
                    solClient_container_addUint32 (cachedMap_p, mapEntry.value.uint32, fieldName_p);
                    break;
                 case SOLCLIENT_INT32:
                    solClient_container_addInt32 (cachedMap_p, mapEntry.value.int32, fieldName_p);
                    break;
                 case SOLCLIENT_UINT64:
                    solClient_container_addUint64 (cachedMap_p, mapEntry.value.uint64, fieldName_p);
                    break;
                 case SOLCLIENT_INT64:
                    solClient_container_addInt64 (cachedMap_p, mapEntry.value.int64, fieldName_p);
                    break;
                 case SOLCLIENT_WCHAR:
                    solClient_container_addWchar (cachedMap_p, mapEntry.value.wchar, fieldName_p);
                    break;
                 case SOLCLIENT_STRING:
                    solClient_container_addString (cachedMap_p, mapEntry.value.string, fieldName_p);
                    break;
                 case SOLCLIENT_BYTEARRAY:
                    solClient_container_addByteArray (cachedMap_p, mapEntry.value.bytearray, mapEntry.length, fieldName_p);
                    break;
                 case SOLCLIENT_FLOAT:
                    solClient_container_addFloat (cachedMap_p, mapEntry.value.float32, fieldName_p);
                    break;
                 case SOLCLIENT_DOUBLE:
                    solClient_container_addDouble (cachedMap_p, mapEntry.value.float64, fieldName_p);
                    break;
                 case SOLCLIENT_MAP:
                    solClient_container_addContainer (cachedMap_p, mapEntry.value.map, fieldName_p);
                    solClient_container_closeMapStream(& mapEntry.value.map );
                    break;
                 case SOLCLIENT_STREAM:
                    solClient_container_addContainer (cachedMap_p, mapEntry.value.stream, fieldName_p);
                    solClient_container_closeMapStream(& mapEntry.value.stream );
                    break;
                 case SOLCLIENT_NULL:
                    solClient_container_addNull (cachedMap_p, fieldName_p);
                    break;
                 case SOLCLIENT_DESTINATION:
                    solClient_container_addDestination (cachedMap_p, &mapEntry.value.dest, sizeof(mapEntry.value.dest), fieldName_p);
                    break;
                 case SOLCLIENT_SMF:
                    solClient_container_addSmf (cachedMap_p, mapEntry.value.smf, mapEntry.length, fieldName_p);
                    break;
                 case SOLCLIENT_UNKNOWN:
                    solClient_container_addUnknownField (cachedMap_p, mapEntry.value.unknownField, mapEntry.length, fieldName_p);
                    break;
                 }
            }
            solClient_container_closeMapStream(&newFieldsMap_p);
        }
        solClient_container_closeMapStream(&cachedMap_p);
    }

    solClient_container_closeMapStream(&rxMap_p);

}

extern "C" void 
solCache_plugin(solCache_pluginEventInfo_t *eventInfo_p)
{
    solCachePluginCount_s ++ ;      // increment counter of number of non-data events seen 

    if ( eventInfo_p->event == SOLCACHE_INGRESS_EVENT_INIT ) 
    {
        eventInfo_p->u.init.pluginFuncs_p->pluginArray[SOLCACHE_INGRESS_EVENT_DATA_MSG] = solCache_data_plugin;
        sc_getNextCachedMsg_p = eventInfo_p->u.init.utilFuncs_p->msgRetriever_p;
    }
    else if (eventInfo_p->event == SOLCACHE_INGRESS_EVENT_DATA_MSG )
    {
        /*
         * this should indicate the plugin is running with an older (plugin V1) Solace PubSub+ Cache.
         * The cache message retrieval functions won't work (or exist) and message modification is 
         * not possible
         */
        solCache_data_plugin (eventInfo_p);
    }
}

/*
 * Test Scenario:
 *
 * This plugin may be tested with sdkperf_c.  Create a structured-data message file 
 * that describes the message. Publish a message on the topic, then verify the cached
 * message has been changed. For example:
 *
 * create the file sdm_testCachePlugin.txt with the following contents:
 *       msg: type=map
 *       msg: useBinaryAttachment=1
 *         uint32 name=testCounter value=42
 *
 * Comments:  The uint32 value=42 is the starting value of the counter that is incremented in the test below.
 *
 * Publish a message on a topic the Solace PubSub+ Cache is configured to cache, in the example we use
 * 'my/sample/topic'.
 *
 * sdkperf_c -cip=192.168.160.128 -cu=publisher -ptl=my/sample/topic -mn=1 -sdm=sdm_testCachePlugin.txt 
 *
 * Retrieve the message from Solace PubSub+ Cache and display its contents.
 *
 * sdkperf_c -cip=192.168.160.128 -cu=cacheReader -chpn=distributed-cache -chrn=1 -ptl=my/sample/topic -md
 *
 * The message contents displayed by sdkperf_c should match:
 *       ^^^^^^^^^^^^^^^^^^ Start Message ^^^^^^^^^^^^^^^^^^^^^^^^^^^
 *       Destination:                            Topic 'my/sample/topic'
 *       Class Of Service:                       COS_1
 *       DeliveryMode:                           DIRECT
 *       Message from cache
 *       Cache Request Id:                       0
 *       User Data:                              len=1
 *         32                                                    2
 *       Binary Attachment Map:
 *         Key 'testCounter' (UINT32) 42
 *       
 *       ^^^^^^^^^^^^^^^^^^ End Message ^^^^^^^^^^^^^^^^^^^^^^^^^^^
 *
 * 
 * Now send a message that will modify and cache the existing cached message.  
 * Create the file sdm_modifyCachePlugin.txt with the following contents:
 *
 *    msg: type=map
 *    msg: useBinaryAttachment=1
 *      string name=modifyTopic value=my/sample/topic
 *      string name=incCounter value=test3Counter
 *      int32 name=testNumber value=19
 *
 * Comments:
 *     When the plugin receives this message, it will retrieve the existing cached message on 'my/sample/topic' and 
 *     apply the modification request (incCounter).  The incoming message is discarded and the modified message is cached
 *     instead.
 *
 * Publish a message on a topic the Solace PubSub+ Cache is configured to cache, in the example we use
 * 'my/sample/topic'.
 *
 * sdkperf_c -cip=192.168.160.128 -cu=publisher -ptl=my/sample/topic -mn=1 -sdm=sdm_modifyCachePlugin.txt 
 *
 * Retrieve the message from Solace PubSub+ Cache and display its contents, which should have the testCounter value incremented.
 *
 * sdkperf_c -cip=192.168.160.128 -cu=cacheReader -chpn=distributed-cache -chrn=1 -ptl=my/sample/topic -md
 *
 * The message contents displayed by sdkperf_c should match:
 *       ^^^^^^^^^^^^^^^^^^ Start Message ^^^^^^^^^^^^^^^^^^^^^^^^^^^
 *       Destination:                            Topic 'my/sample/topic'
 *       Class Of Service:                       COS_1
 *       DeliveryMode:                           DIRECT
 *       Message from cache
 *       Cache Request Id:                       0
 *       User Data:                              len=1
 *         32                                                    2
 *       Binary Attachment Map:
 *         Key 'testCounter' (UINT32) 43
 *       
 *       ^^^^^^^^^^^^^^^^^^ End Message ^^^^^^^^^^^^^^^^^^^^^^^^^^^
 */
