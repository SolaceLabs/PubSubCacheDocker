/* Copyright 2015-2020 Solace Corporation. All rights reserved. */

#ifndef __SOLCACHE_PLUGIN_H_
#define __SOLCACHE_PLUGIN_H_

#if defined(__cplusplus)
extern "C"
{
#endif   /* _cplusplus */


#include <stdint.h>

#include "solClient.h"


/* Return code from the solCache_plugin_loadGlobal() and thread initialization entry points */
typedef enum solCache_returnCode {
    SOLCACHE_OK          = 0,
    SOLCACHE_FAIL        = -1,
} solCache_returnCode_t;

/* Trickery needed to turn a #define string into a quoted string */
#define solCache_str(s)  #s
#define solCache_xstr(s) solCache_str(s)

/*
 * Array of property name / property value pairs containing any cache configuration file entries
 * that begin with "PLUGIN_". The property names are case-insensitive (and should be matched in a 
 * case-insensitive manner). The property value for each property name is always present and is a string.
 * The final entry in the array is always a NULL pointer.
 */
typedef const char **solCache_propertyArray_pt;

/*
 * The plugin must supply solCache_plugin_loadGlobal() as a public interface to the plugin. This is the 
 * only symbol that is looked up by the cache in the dynamic library.
 *
 * solCache_plugin_loadGlobal() is the first routine invoked by the cache when the plugin dynamic
 * library is loaded. 
 *
 * When invoked, the plugin can do any global-scope initialization it needs to perform. Note however
 * that the plugin can be invoked by multiple threads for message processing, and data used for such
 * processing should be kept on a per-thread basis so that the data can be accessed in a thread-safe,
 * lock-less manner. The cache will separately initialize each thread to allow data to be allocated
 * on a per-thread basis (see solCache_plugin_initializeThread_pt below).
 *
 * When invoked, solCache_plugin_loadGlobal() must call back into the cache to tell the cache which 
 * entry points it will be providing for the cache to call. Over time, different sets of interface
 * functions may be made available, allowing the plugin API to change over time and allowing the 
 * cache to remain backwards-compatible with older plugins. An example of such a routine, for
 * the version 1.0 interface, is solCache_plugin_initEntryPoints_1_0() as defined further below.
 *
 * The property_pp can be NULL if there are no properties beginning with "PLUGIN_" in the cache 
 * configuration file. Otherwise, it is a NULL-terminated array of string pointer pairs, with the first
 * pointer of the pair being the property name, and the second string pointer of the pair being the
 * property value. The array ends with a NULL pointer. This allows a plugin to be passed configuration 
 * parameters, if required, from the cache configuration file.  The plugin property names should be 
 * matched in a case-insensitive manner.
 *
 * The values from property_pp must be stored if needed by the plugin - the provided pointers CANNOT be 
 * stored as they will not be valid after this call.
 */
solCache_returnCode_t 
solCache_plugin_loadGlobal
    (
        solCache_propertyArray_pt property_pp  /* NULL or pointer to a NULL-terminated array of string pointer pairs */
    );

/* 
 * Structure of a cache message passed to a cache plugin.
 * 
 * When a message is provided by the cache to the plugin (e.g. the new message to be processed, or 
 * the previous message already cached against the topic), all fields provided below are already filled in.
 * 
 * The smfHdrLen tells the plugin the size of the SMF header. The SMF header is always at the start of the SMF
 * data area. 
 *
 * The SMF data area, which includes the SMF header, the binary payload, and other message parts, is of size
 * smfLen. The data offset provides the offset to here the SMF data area begins (i.e. where th SMF header begins).
 *
 * The topicOffset provides the offset from the start of the SMF data area to the first byte of the NUL-terminated
 * topic string. The topicLen provides the length of the topic, including the NUL terminator (i.e. strlen() plus 1).
 *
 * When a cache message is allocated, only the bufSize field is set, and this field indicates the total size 
 * available for SMF data, which may be greater than the size requested. The other fields MUST be set by the plugin
 * as the SMF message is created in the allocated cache message buffer.
 */
typedef struct solCache_plugin_cacheMsg {
    const uint32_t           bufSize;      /* actual data size area available after allocation - filled in by allocator */
    uint32_t                 smfHdrLen;    /* size of the SMF header (first part of message data) */
    uint32_t                 smfLen;       /* overall message size, i.e. number of SMF bytes in the data area */
    const uint8_t            dataOffset;   /* offset from cache message where message storage starts, i.e. first byte of SMF header */
    uint8_t                  topicOffset;  /* offset into message storage where NUL-terminated topic string is */
    uint8_t                  topicLen;     /* length of the topic string (including NUL terminator) */
} solCache_plugin_cacheMsg_t, *solCache_plugin_cacheMsg_pt;

/* Same as above, but this cache message structure is for a message that cannot be modified by the plugin */
typedef struct solCache_plugin_cacheMsgConst {
    const uint32_t           bufSize;      /* actual data size area available after allocation - filled in by allocator */
    const uint32_t           smfHdrLen;    /* size of the SMF header (first part of message data) */
    const uint32_t           smfLen;       /* overall message size, i.e. number of SMF bytes in the data area */
    const uint8_t            dataOffset;   /* offset from cache message where message storage starts, i.e. first byte of SMF header */
    const uint8_t            topicOffset;  /* offset into message storage where NUL-terminated topic string is */
    const uint8_t            topicLen;     /* length of the topic string (including NUL terminator) */
} solCache_plugin_cacheMsgConst_t, *solCache_plugin_cacheMsgConst_pt;

/* 
 * Routines available to the plugin for allocating and freeing message buffers.
 * These routines require an opaque value to be passed in which is unique to 
 * each thread of execution. This opaque_p is provide for each thread in the 
 * thread initialization entry point (solCache_plugin_initializeThread_pt).
 *
 */
 
/* 
 * Returns an cache message that can hold at least the requested size
 * of SMF message. The returned message will indicate (via the bufSize member)
 * the actual SMF size available to the plugin.
 * Returns NULL if the allocation fails.
 */
solCache_plugin_cacheMsg_pt
solCache_plugin_cacheMsgAlloc(
   void      *opaque_p,  /* as provided to the thread by the thread initialization function */
   uint32_t   size       /* required size of the SMF area (SMF header and payload) */
);

/* Frees a cache message */
void
solCache_plugin_cacheMsgFree(
   void                        *opaque_p, /* as provided to the thread by the thread initialization function */
   solCache_plugin_cacheMsg_pt  msg_p     /* message to be freed */
);

/* Macro that returns first byte of message payload - returns uint8_t pointer */
#define solCache_plugin_msgDataPtr(cacheMsg_p) (((uint8_t *)(cacheMsg_p)) + (cacheMsg_p)->dataOffset)


/* Return code from plugin received message invocation entry point; indicates message action */
typedef enum solCache_opcode
{
    SOLCACHE_INGRESS_OP_CACHE             = 0,      /**< cache the new message (note that when SolCache is configured
                                                             to only keep the latest message, this is functionally
                                                             SOLCACHE_INGRESS_OP_FLUSH_AND_CACHE */                    
    SOLCACHE_INGRESS_OP_DISCARD           = 1,      /**< discard the new message */
    SOLCACHE_INGRESS_OP_FLUSH_AND_CACHE   = 2,      /**< flush the cache contents for the topic, and cache the new message */
    SOLCACHE_INGRESS_OP_FLUSH_AND_DISCARD = 3,      /**< flush the cache contents for the topic and discard the new message */
    SOLCACHE_INGRESS_OP_FAIL              = 4       /**< discard message and take appropriate action for failure (solCache continues but reports 'suspect' in responses to client requests) */
} solCache_opcode_t;

/* 
 * Entry points to the plugin which are invoked by the cache.
 */

/* 
 * Mandatory entry point provided by the plugin to get the description of the plugin.
 * This must return a NULL-terminated constant string pointer which describes the plugin and its version.
 * This information is reported to the Cache Manager.
 */
typedef const char* (*solCache_plugin_getDescriptionGlobal_pt)
    (
        void
    );

/* 
 * Mandatory entry point provided by the plugin to initialize each thread of execution.
 * The plugin should allocate resources that it wants to hold on a per-thread basis to allow
 * plugin threads to run in parallel with no dependence on each other (i.e avoid shared structures
 * have have to be protected). The plugin returns a pointer to allocated data for each thread, and
 * the cache returns this pointer to other entry points when invoked for that thread.
 *
 * The allocOpaque_p must be stored in the thread data created and is used in routines to allocate
 * for free cache messages. This value is thread-specific.
 */
typedef solCache_returnCode_t (*solCache_plugin_initializeThread_pt)
    (
        void                        **user_pp,        /* plugin can allocate resources and store a reference in this location - passed into other plugin API calls */
        void                         *allocOpaque_p   /* parameter that must be passed to the message buffer allocate and free routines - different for each thread */
    );

/* 
 * Mandatory entry point provided by the plugin - used to clean up any resources plugin previously allocated (per thread)
 * This entry point can be invoked in parallel by different threads.
 */
typedef void (*solCache_plugin_cleanupThread_pt)
    (
        void                         *user_p        /* opaque plugin data created during the per-thread initialization call */
    );

/* 
 * Mandatory entry point provided by the cache to handle new incoming messages.
 * This entry point can be invoked in parallel by different threads.
 * user_p is the pointer previously returned by the plugin during initialization for that thread.
 *
 * The plugin is always given a non-NULL newMsg_p to process. The plugin is allowed to modify the new message if it
 * wishes, but it must not free the new message. Generally, modifying the new message is not recommended, and rather
 * allocating a new message to merge the newMsg_p and prevMsg_p into is recommended.
 *
 * The prevMsg_p is non-null if there is a previous message for the topic in the cache. If the cache stores multiple messages 
 * per topic, this is the most recent message cached for the topic.
 *
 * If the return code is SOLCACHE_INGRESS_OP_CACHE or SOLCACHE_INGRESS_OP_FLUSH_AND_CACHE, the cache will cache the 
 * returnMsg_p if it is not NULL, and will also free the newMsg_p if it is not the same as the returnMsg_p. If the 
 * returnMsg_p is NULL, then the cache will cache the newMsg_p. Note that the newMsg_p may be the untouched received
 * message, or it may have been manipulated by the cache. However, if the cache is manipulating newMsg_p, it should always
 * return the mesa age to be cached in returnMsg_p, since the manipulation may require the allocation of a different message
 * buffer.
 *
 * If the return code is SOLCACHE_INGRESS_OP_DISCARD or SOLCACHE_INGRESS_OP_FLUSH_AND_DISCARD, the returnMsg_p, if not NULL,
 * is freed by the cache, and the newMsg_p, if not the same as returnMsg_p, is freed by the cache.
 */
typedef solCache_opcode_t (*solCache_plugin_receivedMessageThread_pt)
    (
        void                             *user_p,       /* opaque plugin data created during the per-thread initialization call */
        solCache_plugin_cacheMsg_pt       newMsg_p,     /* newly arrived message for the plugin to process */
        solCache_plugin_cacheMsgConst_pt  prevMsg_p,    /* most recent previous message stored for the topic, NULL if none */
        solCache_plugin_cacheMsg_pt      *returnMsg_pp  /* new merged message returned from the plugin if one was produced */
    );

/* 
 * Optional entry point provided by the plugin to clear any stats that are held by the plugin on a global basis.
 * In general, stats should be kept on a per-thread basis to allow for thread independence, but some statistics may
 * be global in nature or held by thread-safe third party libraries that are invoked by the plugin.
 * This routine is invoked once when a cache clear stats command is received from the Cache Manager.
 */
typedef void (*solCache_plugin_clearStatsGlobal_pt)
    (
        void
    );
            
/* 
 * Optional entry point provided by the plugin to clear any stats that are held by the plugin on a per-thread basis.
 * This is invoked when a cache clear stats command is received from the Cache Manager.
 * This entry point can be invoked in parallel by different threads (e.g. with that thread's user_p).
 * user_p is the pointer previously returned by the plugin during initialization for that thread.
 */
typedef void (*solCache_plugin_clearStatsThread_pt)
    (
        void                         *user_p        /* opaque plugin data created during the per-thread initialization call */
    );

/*
 * Optional entry point provided by the plugin to output debug information held by the plugin on a global basis.
 * This is invoked once when a cache debug dump command is received.
 * The dump output should be indented by two spaces at the top level of dump output, e.g. fprintf(file, "  xxxx\n")
 */
typedef void (*solCache_plugin_debugDumpGlobal_pt)
    (
        FILE                         *file          /* file to write to (already open, must not be closed) */        
    );

/*
 * Optional entry point provided by the plugin to output debug information held by the plugin on a per-thread basis.
 * This is invoked when a cache debug dump command is received. This entry point, while invoked per-thread, is invoked 
 * serially so that the file output will not have contention.
 * The dump output should be indented by two spaces at the top level of dump output, , e.g. fprintf(file, "  xxxx\n")
 */
typedef void (*solCache_plugin_debugDumpThread_pt)
    (
        void                         *user_p,       /* opaque plugin data created during the per-thread initialization call */
        FILE                         *file          /* file to write to (already open, must not be closed) */        
    );

/* 
 * Optional entry point provided by the plugin - used to clean up any resources the plugin previously allocated
 * on a global basis. This entry point can also be used by the plugin to perform global clean up of third-party 
 * libraries that the plugin uses. This entry point is invoked once and is the last entry point called.
 */
typedef void (*solCache_plugin_unloadGlobal_pt)
    (
        void
    );

/* 
 * Optional entry point provided by the plugin - called when the cache configuration file is
 * reloaded. The plugin is provided with any property values that begin with "PLUGIN_". The plugin
 * is provided with any such properties whether or not they have changed in value. The plugin must
 * decide which PLUGIN_ property values, if any, it chooses to examine and act on. Some PLUGIN_
 * property values may only be acted on by the plugin when initially loaded 
 * -- in solCache_plugin_loadGlobal() -- and not support having the value changed during a 
 * configuration file reload.
 *
 * The property_pp parameter is as described in solCache_plugin_loadGlobal().
 *
 * The values from property_pp must be stored if needed by the plugin - the provided pointers CANNOT be 
 * stored as they will not be valid after this call.
 */
typedef solCache_returnCode_t (*solCache_plugin_reloadPropertiesGlobal_pt)
    (
        solCache_propertyArray_pt property_pp  /* NULL or pointer to a NULL-terminated array of string pointer pairs */
    );

/* 
 * Routine provided by the cache to the plugin, which must be called by the plugin within
 * solCache_plugin_loadGlobal(). This allows the plugin to tell the cache all the plugin
 * entry points which the cache is to invoke during caching operations.
 *
 * Over time, the cache may offer additional entry points to allow the plugin to choose
 * a different interface style with the cache or as support for new entry functions are added,
 * allowing for the expansion of the plugin interface and allowing the cache to be compatible 
 * with plugins that wish to use different interfaces offered by the cache.
 *
 * Currently, the cache only supports interface version 1.0. The plugin must call
 * solCache_plugin_initEntryPoints_1_0() to define all the entry points in use.
 *
 * The cache will return SOLCACHE_OK or SOLCACHE_FAIL. The invocation can fail, for example, if 
 * the plugin fails to supply all mandatory entry points. Optional entry points can be NULL and
 * do not have to be implemented within the plugin.
 */
solCache_returnCode_t
solCache_plugin_initEntryPoints_1_0(
    solCache_plugin_getDescriptionGlobal_pt   getDescriptionGlobal_p,   /* Mandatory */
    solCache_plugin_initializeThread_pt       initializeThread_p,       /* Mandatory */
    solCache_plugin_cleanupThread_pt          cleanupThread_p,          /* Mandatory */
    solCache_plugin_receivedMessageThread_pt  receivedMessageThread_p,  /* Mandatory */
    solCache_plugin_clearStatsGlobal_pt       clearStatsGlobal_p,       /* Optional */
    solCache_plugin_clearStatsThread_pt       clearStatsThread_p,       /* Optional */
    solCache_plugin_debugDumpGlobal_pt        debugDumpGlobal_p,        /* Optional */
    solCache_plugin_debugDumpThread_pt        debugDumpThread_p,        /* Optional */
    solCache_plugin_unloadGlobal_pt           unloadGlobal_p,           /* Optional */
    solCache_plugin_reloadPropertiesGlobal_pt reloadPropertiesGlobal_p  /* Optional */
);

/* Logging utilities */

/* Levels for logging */
#define SOLCACHE_LOG_EMERGENCY  SOLCLIENT_LOG_EMERGENCY
#define SOLCACHE_LOG_ALERT      SOLCLIENT_LOG_ALERT
#define SOLCACHE_LOG_CRITICAL   SOLCLIENT_LOG_CRITICAL
#define SOLCACHE_LOG_ERROR      SOLCLIENT_LOG_ERROR 
#define SOLCACHE_LOG_WARNING    SOLCLIENT_LOG_WARNING 
#define SOLCACHE_LOG_NOTICE     SOLCLIENT_LOG_NOTICE   
#define SOLCACHE_LOG_INFO       SOLCLIENT_LOG_INFO   
#define SOLCACHE_LOG_DEBUG      SOLCLIENT_LOG_DEBUG

#define solCache_log(level, ...) solClient_log(level, __VA_ARGS__)

#define solCache_log_va_list(level, format_p, ap) solClient_log_va_list(level, format_p, ap)

#define solCache_logLevelToString(...) solClient_logLevelToString(__VA_ARGS__)



#if defined(__cplusplus)
}
#endif   /* _cplusplus */


#endif /* __SOLCACHE_PLUGIN_H_ */
