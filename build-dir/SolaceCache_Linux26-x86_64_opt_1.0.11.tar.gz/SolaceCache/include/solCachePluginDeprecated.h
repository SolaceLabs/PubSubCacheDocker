/* Copyright 2015-2020 Solace Corporation. All rights reserved. */

#ifndef __SOLCACHE_PLUGIN_DEPRECATED_H_
#define __SOLCACHE_PLUGIN_DEPRECATED_H_

#include "solCachePlugin.h"


#if defined(__cplusplus)
extern "C"
{
#endif   /* _cplusplus */


/**
 * @enum solCache_pluginEvent
 *
 * This enum defines the different events that trigger the cache to call the plugin function. The
 * plugin function may choose to act on these events or do nothing and return.
 */

typedef enum solCache_pluginEvent
{
	SOLCACHE_INGRESS_EVENT_DATA_MSG = 0,    /**< ingress data message that is about to be cached */
    SOLCACHE_INGRESS_EVENT_INIT             /**< plug-in initialization/registration */
} solCache_pluginEvent_t;


/* Forward declaration */
typedef struct solCache_pluginEventInfo *solCache_pluginEventInfo_pt;

/**<
 * typdef solCache_pluginFunc_pt
 * A pointer to a function returning void. This function has the same signature as solCache_plugin().
 * An application may change the callback to another callback by setting the callback pointer associated with the
 * event before returning from the SOLCACHE_INGRESS_EVENT_INIT event callback. 
 *
 * @param eventInfo_p   A pointer to the solCache_pluginEventInfo structure with more details on the event.
 * @returns void
 */

typedef void
        (*solCache_pluginFunc_pt) (solCache_pluginEventInfo_pt eventInfo_p);


/**<
 * typdef solCache_getNextCachedMsgFunc_t
 * A pointer to a function returning a solClient_opaqueMsg_pt.  This function is provided by the cache to plugin 
 * developers.  It allows the plugin to retrieve a cached message on the topic of the received messages.
 * The plugin <b>must</b> release the message pointer when it is no longer in use by calling solClient_msg_free(). 
 *
 * The Solace PubSub+ Cache only supports retrieving messages of the SAME topic as the received message.
 * The topic, if not NULL, is not checked and the next message for the same topic as the received message
 * is returned. Retrieving messages from a different topic from the topic of the received message is not supported.
 *
 * Modifications made to the message have no effect on cached messages. Cached memory is <b>not</b> modified through
 * these opaque message pointers. However a retrieved message can be modified and returned instead of the received 
 * message when the plugin is handling SOLCACHE_INGRESS_EVENT_DATA_MSG and so cached messages can be modified indirectly.
 * If the plugin chooses to replace the received message pointer, then the message pointer retrieved by this function
 * <b>must not</b> be released as it is still considered 'in-use'.  
 *
 * In no situation should the plugin ever release the message pointer for the originally received message, including if that
 * message pointer is overwritten by the plugin.
 * 
 * @param topic_p The topic used to retrieve cached messages. If non-null the newest message on the topic of the received
 *                message is retrieved - the provided topic_p is ignored other than the check for non-NULL. 
 *                If NULL then the next message on the topic of the received message is retrieved. For each invocation 
 *                of the plugin callback, topic_p <b>must</b> be set to non-NULL on the first invocation of this method.
 * @returns solClient_opaqueMsg_pt referencing a cached message on the topic of the received message. If no messages, 
 *                or no further messages, are cached on the topic of the received message, this function returns NULL.
 */

typedef void *solCache_opaqueIter_pt;
typedef solClient_opaqueMsg_pt
        (*solCache_getNextCachedMsgFunc_t) ( const char * topic_p );

struct solCache_utilityFuncs
{
    solClient_uint32_t                      numUtils;       /*  Number of utilities provided by the cache */
    solCache_getNextCachedMsgFunc_t         msgRetriever_p;
};

struct solCache_pluginFuncs
{
    solClient_uint32_t              numEvents;              /* Number of events supported by the cache */
    solCache_pluginFunc_pt          pluginArray[1];         /* Array actual size is numEvents */
};

struct solCache_initEventInfo_t
{
    struct solCache_pluginFuncs     *pluginFuncs_p; /* OUT: pointers to functions the cache will call for generated events */
    struct solCache_utilityFuncs    *utilFuncs_p;   /* IN: pointers to functions the plugin may call */
};


/**
 * @struct solCache_pluginEventInfo
 *
 * This structure is used to pass parameters to the plugin function and receive parameters from the
 * plugin function.
 * 
 * When processing a SOLCACHE_INGRESS_EVENT_DATA_MSG, the received message structure referenced by msg_p
 * remains owned by the cache. The application must not use this reference after returning from the plugin.
 * The application must not release this reference by calling solClient_msg_free().
 * The plugin may:
 * - examine or copy the received message. 
 * - modify the contents of the received message.  If the message is modified, the modified message is
 *   cached by the cache on return from the plugin, as long as the plugin opCode indicates the message should 
 *   be cached and it is cache-able. The new message will be cached in lieu of the received message and must contain 
 *   sufficient information to be encoded as valid message (in a minimum it should contain a 'topic' and a 
 *   'binary attachment'). The topic MUST be the same as the topic of the received message. When the plugin chooses 
 *   this option, the new msg_p and the original msg_p are owned by the cache.  Neither reference should be released 
 *   by solClient_msg_free(), and neither reference may be used after the plugin returns.
 *
 * The Solace PubSub+ Cache does not support the plugin producing a message for a different topic than the topic of 
 * the received message. The plugin MUST return a message with the SAME topic as the topic of the received
 * message. The return topic is not checked and is assumed to be the same. Thus, all return actions, such as 
 * SOLCACHE_INGRESS_OP_FLUSH_AND_DISCARD always operated on the topic of the received message which was processed by the
 * plugin. The plugin is unable to operate on or affect any other topic.
 */

typedef struct solCache_pluginEventInfo
{
	solCache_pluginEvent_t event;       /**< event code provided to plugin function */
	solClient_opaqueMsg_pt msg_p;       /**< message being processed by the cache, only valid in SOLCACHE_INGRESS_EVENT_DATA_MSG. */
	solCache_opcode_t opcode;           /**< opcode returned to the cache by the plugin function */
        union
        {
            struct solCache_initEventInfo_t     init;   /**< SOLCACHE_INGRESS_EVENT_INIT */
        } u;
} solCache_pluginEventInfo_t;



#if defined(__cplusplus)
}
#endif   /* _cplusplus */


#endif   /* __SOLCACHE_PLUGIN_DEPRECATED_H_ */

